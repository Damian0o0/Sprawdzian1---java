import java.io.BufferedWriter;
import java.io.File;
import java.io.IOException;
import java.io.FileWriter;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) throws Exception {
    ZapisDoPliku();
    }
    public static  void ZapisDoPliku() {
        String sciezka = "dane1.txt";
        try{
            FileWriter file = new FileWriter(sciezka, true);
            BufferedWriter bWriter = new BufferedWriter(file);
            ///Zad1
            bWriter.write("Język angielski \n");
            bWriter.write("Język polski \n");
            bWriter.write( "Matematyka \n");
            bWriter.write( "W-F \n");
            bWriter.write( "Projektowanie i administrowanie bazami danych \n" );
            ////zad2
            bWriter.write("Historia \n");
            bWriter.write("Język rosyjski \n");
            bWriter.write("Geografia");
            bWriter.close();
        } catch (IOException e) {
            System.out.println("Błąd zapisu do pliku");
        }
    }
}