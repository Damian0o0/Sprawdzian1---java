import java.io.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
///////////////////////////////zad3, 4 i 5
public class Main {
    public static void main(String[] args) throws Exception {
        OdczytZPliku();
    }
    public static void OdczytZPliku(){
    try {
        File pog = new File("D:/Damian Górka/zad3-4-5/zad3.txt");
        Scanner pogchamp = new Scanner(pog);
        List<Integer> lista = new ArrayList<>();
        while (pogchamp.hasNextInt()) {
            lista.add(pogchamp.nextInt());
        }
        for (Integer elem : lista) {
            System.out.println(elem + " ");
        }
            System.out.println();
            pogchamp.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
    }

    }
}