import java.io.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.Random;
public class Main {
    public static void main(String[] args) {
        Zadanie1();
    }
    public static void Zadanie1(){
        Scanner JD = new Scanner(System.in);
        System.out.println("Podaj tekst: ");
        String KX = JD .nextLine();
        if(KX.length() >= 10){
        }
        else{
            int POG = 10 - KX.length();
            for(int i = 0; POG > i; i++){
                Random random = new Random();
                char lol = (char)(random.nextInt(26) + 'a');
                KX = KX + lol;
            }
            System.out.println(KX);
        }
    }
}
