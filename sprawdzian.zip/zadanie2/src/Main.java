import java.io.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.Random;
public class Main {
    public static void main(String[] args) {

        ////////////////////zad2
        Scanner input = new Scanner(System.in);
        System.out.println("Podaj liczbę, dla której chcesz znaleźć dopełnienie: ");
        int liczba = input.nextInt();

        int int1 = 9999 - liczba;
        int int2 = 99999 - liczba;
        int int3 = 999999 - liczba;
        int int4 = 9999999 - liczba;

        if (String.valueOf(liczba).charAt(0) == '9')
            System.out.println("Nie możesz zacząć liczby od 9.");
        else if (String.valueOf(liczba).charAt(0) == '0')
            System.out.println("Nie możesz zacząć liczby od 0.");
        else if (liczba > 9999)
            System.out.println("Dopełnienie tej liczby to: " + int2);
        else if (liczba > 99999)
            System.out.println("Dopełnienie tej liczby to: " + int3);
        else if (liczba > 999999)
            System.out.println("Dopełnienie tej liczby to: " + int4);
        else
            System.out.println("Dopełnienie tej liczby to: " + int1);
    }
}
